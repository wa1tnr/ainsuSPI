// Update this when the library is updated. Its not included by default.

#define ASF_VERSION "3.32.0"
