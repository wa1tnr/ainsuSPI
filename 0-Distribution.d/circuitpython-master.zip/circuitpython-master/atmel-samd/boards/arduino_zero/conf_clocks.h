#include "conf_clocks_external_32k.h"
