// No busio module functions.
