// No audioio module functions.
