// No analogio module functions.
