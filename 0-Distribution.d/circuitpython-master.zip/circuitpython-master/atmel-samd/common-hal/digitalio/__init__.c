// No digitalio module functions.
