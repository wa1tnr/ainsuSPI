// No pulseio module functions.
