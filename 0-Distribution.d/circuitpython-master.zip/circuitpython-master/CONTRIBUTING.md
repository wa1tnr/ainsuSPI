# Contributing

Please note that this project is released with a Contributor Code of
Conduct. By participating in this project you agree to abide by its terms.

https://github.com/adafruit/micropython/blob/master/CODE_OF_CONDUCT.md

When reporting an issue and especially submitting a pull request, please
make sure that you are acquainted with Contributor Guidelines:

https://github.com/micropython/micropython/wiki/ContributorGuidelines

and Code Conventions:

https://github.com/micropython/micropython/blob/master/CODECONVENTIONS.md
